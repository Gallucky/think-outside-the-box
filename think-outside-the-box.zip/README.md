# think-outside-the-box
HTML &amp; CSS implementation of a Figma UI design using SASS. Referenced by the portfolio project.
